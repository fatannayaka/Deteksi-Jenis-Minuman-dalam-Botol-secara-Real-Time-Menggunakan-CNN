# UAS KCB (OBJECT DETECTION) > baru lagi ini
https://universe.roboflow.com/project-kcb/uas-kcb-object-detection-k5ppd

Provided by a Roboflow user
License: Public Domain

